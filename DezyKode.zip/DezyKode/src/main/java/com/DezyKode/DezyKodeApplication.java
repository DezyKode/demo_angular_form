package com.DezyKode;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DezyKodeApplication {

	public static void main(String[] args) {
		SpringApplication.run(DezyKodeApplication.class, args);
		System.out.println("application running");
	}

}
