<!DOCTYPE html><html lang="en-IN"><head><link rel="icon" href="//img1.wsimg.com/isteam/ip/66f40e72-7c50-49d9-aa9b-3b320019d517/favicon/cbb79738-c95c-4bbf-9e22-1268afb3187d.png/:/rs=w:16,h:16,m" sizes="16x16"/><link rel="icon" href="//img1.wsimg.com/isteam/ip/66f40e72-7c50-49d9-aa9b-3b320019d517/favicon/cbb79738-c95c-4bbf-9e22-1268afb3187d.png/:/rs=w:24,h:24,m" sizes="24x24"/><link rel="icon" href="//img1.wsimg.com/isteam/ip/66f40e72-7c50-49d9-aa9b-3b320019d517/favicon/cbb79738-c95c-4bbf-9e22-1268afb3187d.png/:/rs=w:32,h:32,m" sizes="32x32"/><link rel="icon" href="//img1.wsimg.com/isteam/ip/66f40e72-7c50-49d9-aa9b-3b320019d517/favicon/cbb79738-c95c-4bbf-9e22-1268afb3187d.png/:/rs=w:48,h:48,m" sizes="48x48"/><link rel="icon" href="//img1.wsimg.com/isteam/ip/66f40e72-7c50-49d9-aa9b-3b320019d517/favicon/cbb79738-c95c-4bbf-9e22-1268afb3187d.png/:/rs=w:64,h:64,m" sizes="64x64"/><meta charSet="utf-8"/><meta http-equiv="X-UA-Compatible" content="IE=edge"/><meta name="viewport" content="width=device-width, initial-scale=1"/><title>Dezykode</title><meta name="author" content="Dezykode"/><meta name="generator" content="Starfield Technologies; Go Daddy Website Builder 8.0.0000"/><link rel="manifest" href="/manifest.webmanifest"/><link rel="apple-touch-icon" sizes="57x57" href="//img1.wsimg.com/isteam/ip/66f40e72-7c50-49d9-aa9b-3b320019d517/Logo%20n%20name.jpg/:/rs=w:57,h:57,m"/><link rel="apple-touch-icon" sizes="60x60" href="//img1.wsimg.com/isteam/ip/66f40e72-7c50-49d9-aa9b-3b320019d517/Logo%20n%20name.jpg/:/rs=w:60,h:60,m"/><link rel="apple-touch-icon" sizes="72x72" href="//img1.wsimg.com/isteam/ip/66f40e72-7c50-49d9-aa9b-3b320019d517/Logo%20n%20name.jpg/:/rs=w:72,h:72,m"/><link rel="apple-touch-icon" sizes="114x114" href="//img1.wsimg.com/isteam/ip/66f40e72-7c50-49d9-aa9b-3b320019d517/Logo%20n%20name.jpg/:/rs=w:114,h:114,m"/><link rel="apple-touch-icon" sizes="120x120" href="//img1.wsimg.com/isteam/ip/66f40e72-7c50-49d9-aa9b-3b320019d517/Logo%20n%20name.jpg/:/rs=w:120,h:120,m"/><link rel="apple-touch-icon" sizes="144x144" href="//img1.wsimg.com/isteam/ip/66f40e72-7c50-49d9-aa9b-3b320019d517/Logo%20n%20name.jpg/:/rs=w:144,h:144,m"/><link rel="apple-touch-icon" sizes="152x152" href="//img1.wsimg.com/isteam/ip/66f40e72-7c50-49d9-aa9b-3b320019d517/Logo%20n%20name.jpg/:/rs=w:152,h:152,m"/><link rel="apple-touch-icon" sizes="180x180" href="//img1.wsimg.com/isteam/ip/66f40e72-7c50-49d9-aa9b-3b320019d517/Logo%20n%20name.jpg/:/rs=w:180,h:180,m"/><meta property="og:url" content="https://dezykode.com/404"/>
<meta property="og:site_name" content="Dezykode"/>
<meta property="og:title" content="Dezykode"/>
<meta property="og:description" content="Be a  Master the Future of Technology.   Design, Develop, Succeed."/>
<meta property="og:type" content="website"/>
<meta property="og:image" content="https://img1.wsimg.com/isteam/videos/V8qnemn"/>
<meta property="og:locale" content="en_IN"/>
<meta name="twitter:card" content="summary"/>
<meta name="twitter:title" content="Dezykode"/>
<meta name="twitter:description" content="Innovative Solution for the future generation"/>
<meta name="twitter:image" content="https://img1.wsimg.com/isteam/videos/V8qnemn"/>
<meta name="twitter:image:alt" content="Dezykode"/>
<meta name="theme-color" content="#272425"/><style data-inline-fonts>/* cyrillic-ext */
@font-face {
  font-family: 'Roboto';
  font-style: italic;
  font-weight: 300;
  font-display: swap;
  src: url(https://img1.wsimg.com/gfonts/s/roboto/v32/KFOjCnqEu92Fr1Mu51TjASc3CsTKlA.woff2) format('woff2');
  unicode-range: U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F;
}
/* cyrillic */
@font-face {
  font-family: 'Roboto';
  font-style: italic;
  font-weight: 300;
  font-display: swap;
  src: url(https://img1.wsimg.com/gfonts/s/roboto/v32/KFOjCnqEu92Fr1Mu51TjASc-CsTKlA.woff2) format('woff2');
  unicode-range: U+0301, U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116;
}
/* greek-ext */
@font-face {
  font-family: 'Roboto';
  font-style: italic;
  font-weight: 300;
  font-display: swap;
  src: url(https://img1.wsimg.com/gfonts/s/roboto/v32/KFOjCnqEu92Fr1Mu51TjASc2CsTKlA.woff2) format('woff2');
  unicode-range: U+1F00-1FFF;
}
/* greek */
@font-face {
  font-family: 'Roboto';
  font-style: italic;
  font-weight: 300;
  font-display: swap;
  src: url(https://img1.wsimg.com/gfonts/s/roboto/v32/KFOjCnqEu92Fr1Mu51TjASc5CsTKlA.woff2) format('woff2');
  unicode-range: U+0370-0377, U+037A-037F, U+0384-038A, U+038C, U+038E-03A1, U+03A3-03FF;
}
/* vietnamese */
@font-face {
  font-family: 'Roboto';
  font-style: italic;
  font-weight: 300;
  font-display: swap;
  src: url(https://img1.wsimg.com/gfonts/s/roboto/v32/KFOjCnqEu92Fr1Mu51TjASc1CsTKlA.woff2) format('woff2');
  unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+0300-0301, U+0303-0304, U+0308-0309, U+0323, U+0329, U+1EA0-1EF9, U+20AB;
}
/* latin-ext */
@font-face {
  font-family: 'Roboto';
  font-style: italic;
  font-weight: 300;
  font-display: swap;
  src: url(https://img1.wsimg.com/gfonts/s/roboto/v32/KFOjCnqEu92Fr1Mu51TjASc0CsTKlA.woff2) format('woff2');
  unicode-range: U+0100-02AF, U+0304, U+0308, U+0329, U+1E00-1E9F, U+1EF2-1EFF, U+2020, U+20A0-20AB, U+20AD-20C0, U+2113, U+2C60-2C7F, U+A720-A7FF;
}
/* latin */
@font-face {
  font-family: 'Roboto';
  font-style: italic;
  font-weight: 300;
  font-display: swap;
  src: url(https://img1.wsimg.com/gfonts/s/roboto/v32/KFOjCnqEu92Fr1Mu51TjASc6CsQ.woff2) format('woff2');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+0304, U+0308, U+0329, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}
/* cyrillic-ext */
@font-face {
  font-family: 'Roboto';
  font-style: italic;
  font-weight: 400;
  font-display: swap;
  src: url(https://img1.wsimg.com/gfonts/s/roboto/v32/KFOkCnqEu92Fr1Mu51xFIzIFKw.woff2) format('woff2');
  unicode-range: U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F;
}
/* cyrillic */
@font-face {
  font-family: 'Roboto';
  font-style: italic;
  font-weight: 400;
  font-display: swap;
  src: url(https://img1.wsimg.com/gfonts/s/roboto/v32/KFOkCnqEu92Fr1Mu51xMIzIFKw.woff2) format('woff2');
  unicode-range: U+0301, U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116;
}
/* greek-ext */
@font-face {
  font-family: 'Roboto';
  font-style: italic;
  font-weight: 400;
  font-display: swap;
  src: url(https://img1.wsimg.com/gfonts/s/roboto/v32/KFOkCnqEu92Fr1Mu51xEIzIFKw.woff2) format('woff2');
  unicode-range: U+1F00-1FFF;
}
/* greek */
@font-face {
  font-family: 'Roboto';
  font-style: italic;
  font-weight: 400;
  font-display: swap;
  src: url(https://img1.wsimg.com/gfonts/s/roboto/v32/KFOkCnqEu92Fr1Mu51xLIzIFKw.woff2) format('woff2');
  unicode-range: U+0370-0377, U+037A-037F, U+0384-038A, U+038C, U+038E-03A1, U+03A3-03FF;
}
/* vietnamese */
@font-face {
  font-family: 'Roboto';
  font-style: italic;
  font-weight: 400;
  font-display: swap;
  src: url(https://img1.wsimg.com/gfonts/s/roboto/v32/KFOkCnqEu92Fr1Mu51xHIzIFKw.woff2) format('woff2');
  unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+0300-0301, U+0303-0304, U+0308-0309, U+0323, U+0329, U+1EA0-1EF9, U+20AB;
}
/* latin-ext */
@font-face {
  font-family: 'Roboto';
  font-style: italic;
  font-weight: 400;
  font-display: swap;
  src: url(https://img1.wsimg.com/gfonts/s/roboto/v32/KFOkCnqEu92Fr1Mu51xGIzIFKw.woff2) format('woff2');
  unicode-range: U+0100-02AF, U+0304, U+0308, U+0329, U+1E00-1E9F, U+1EF2-1EFF, U+2020, U+20A0-20AB, U+20AD-20C0, U+2113, U+2C60-2C7F, U+A720-A7FF;
}
/* latin */
@font-face {
  font-family: 'Roboto';
  font-style: italic;
  font-weight: 400;
  font-display: swap;
  src: url(https://img1.wsimg.com/gfonts/s/roboto/v32/KFOkCnqEu92Fr1Mu51xIIzI.woff2) format('woff2');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+0304, U+0308, U+0329, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}
/* cyrillic-ext */
@font-face {
  font-family: 'Roboto';
  font-style: italic;
  font-weight: 700;
  font-display: swap;
  src: url(https://img1.wsimg.com/gfonts/s/roboto/v32/KFOjCnqEu92Fr1Mu51TzBic3CsTKlA.woff2) format('woff2');
  unicode-range: U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F;
}
/* cyrillic */
@font-face {
  font-family: 'Roboto';
  font-style: italic;
  font-weight: 700;
  font-display: swap;
  src: url(https://img1.wsimg.com/gfonts/s/roboto/v32/KFOjCnqEu92Fr1Mu51TzBic-CsTKlA.woff2) format('woff2');
  unicode-range: U+0301, U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116;
}
/* greek-ext */
@font-face {
  font-family: 'Roboto';
  font-style: italic;
  font-weight: 700;
  font-display: swap;
  src: url(https://img1.wsimg.com/gfonts/s/roboto/v32/KFOjCnqEu92Fr1Mu51TzBic2CsTKlA.woff2) format('woff2');
  unicode-range: U+1F00-1FFF;
}
/* greek */
@font-face {
  font-family: 'Roboto';
  font-style: italic;
  font-weight: 700;
  font-display: swap;
  src: url(https://img1.wsimg.com/gfonts/s/roboto/v32/KFOjCnqEu92Fr1Mu51TzBic5CsTKlA.woff2) format('woff2');
  unicode-range: U+0370-0377, U+037A-037F, U+0384-038A, U+038C, U+038E-03A1, U+03A3-03FF;
}
/* vietnamese */
@font-face {
  font-family: 'Roboto';
  font-style: italic;
  font-weight: 700;
  font-display: swap;
  src: url(https://img1.wsimg.com/gfonts/s/roboto/v32/KFOjCnqEu92Fr1Mu51TzBic1CsTKlA.woff2) format('woff2');
  unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+0300-0301, U+0303-0304, U+0308-0309, U+0323, U+0329, U+1EA0-1EF9, U+20AB;
}
/* latin-ext */
@font-face {
  font-family: 'Roboto';
  font-style: italic;
  font-weight: 700;
  font-display: swap;
  src: url(https://img1.wsimg.com/gfonts/s/roboto/v32/KFOjCnqEu92Fr1Mu51TzBic0CsTKlA.woff2) format('woff2');
  unicode-range: U+0100-02AF, U+0304, U+0308, U+0329, U+1E00-1E9F, U+1EF2-1EFF, U+2020, U+20A0-20AB, U+20AD-20C0, U+2113, U+2C60-2C7F, U+A720-A7FF;
}
/* latin */
@font-face {
  font-family: 'Roboto';
  font-style: italic;
  font-weight: 700;
  font-display: swap;
  src: url(https://img1.wsimg.com/gfonts/s/roboto/v32/KFOjCnqEu92Fr1Mu51TzBic6CsQ.woff2) format('woff2');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+0304, U+0308, U+0329, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}
/* cyrillic-ext */
@font-face {
  font-family: 'Roboto';
  font-style: normal;
  font-weight: 100;
  font-display: swap;
  src: url(https://img1.wsimg.com/gfonts/s/roboto/v32/KFOkCnqEu92Fr1MmgVxFIzIFKw.woff2) format('woff2');
  unicode-range: U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F;
}
/* cyrillic */
@font-face {
  font-family: 'Roboto';
  font-style: normal;
  font-weight: 100;
  font-display: swap;
  src: url(https://img1.wsimg.com/gfonts/s/roboto/v32/KFOkCnqEu92Fr1MmgVxMIzIFKw.woff2) format('woff2');
  unicode-range: U+0301, U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116;
}
/* greek-ext */
@font-face {
  font-family: 'Roboto';
  font-style: normal;
  font-weight: 100;
  font-display: swap;
  src: url(https://img1.wsimg.com/gfonts/s/roboto/v32/KFOkCnqEu92Fr1MmgVxEIzIFKw.woff2) format('woff2');
  unicode-range: U+1F00-1FFF;
}
/* greek */
@font-face {
  font-family: 'Roboto';
  font-style: normal;
  font-weight: 100;
  font-display: swap;
  src: url(https://img1.wsimg.com/gfonts/s/roboto/v32/KFOkCnqEu92Fr1MmgVxLIzIFKw.woff2) format('woff2');
  unicode-range: U+0370-0377, U+037A-037F, U+0384-038A, U+038C, U+038E-03A1, U+03A3-03FF;
}
/* vietnamese */
@font-face {
  font-family: 'Roboto';
  font-style: normal;
  font-weight: 100;
  font-display: swap;
  src: url(https://img1.wsimg.com/gfonts/s/roboto/v32/KFOkCnqEu92Fr1MmgVxHIzIFKw.woff2) format('woff2');
  unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+0300-0301, U+0303-0304, U+0308-0309, U+0323, U+0329, U+1EA0-1EF9, U+20AB;
}
/* latin-ext */
@font-face {
  font-family: 'Roboto';
  font-style: normal;
  font-weight: 100;
  font-display: swap;
  src: url(https://img1.wsimg.com/gfonts/s/roboto/v32/KFOkCnqEu92Fr1MmgVxGIzIFKw.woff2) format('woff2');
  unicode-range: U+0100-02AF, U+0304, U+0308, U+0329, U+1E00-1E9F, U+1EF2-1EFF, U+2020, U+20A0-20AB, U+20AD-20C0, U+2113, U+2C60-2C7F, U+A720-A7FF;
}
/* latin */
@font-face {
  font-family: 'Roboto';
  font-style: normal;
  font-weight: 100;
  font-display: swap;
  src: url(https://img1.wsimg.com/gfonts/s/roboto/v32/KFOkCnqEu92Fr1MmgVxIIzI.woff2) format('woff2');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+0304, U+0308, U+0329, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}
/* cyrillic-ext */
@font-face {
  font-family: 'Roboto';
  font-style: normal;
  font-weight: 300;
  font-display: swap;
  src: url(https://img1.wsimg.com/gfonts/s/roboto/v32/KFOlCnqEu92Fr1MmSU5fCRc4EsA.woff2) format('woff2');
  unicode-range: U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F;
}
/* cyrillic */
@font-face {
  font-family: 'Roboto';
  font-style: normal;
  font-weight: 300;
  font-display: swap;
  src: url(https://img1.wsimg.com/gfonts/s/roboto/v32/KFOlCnqEu92Fr1MmSU5fABc4EsA.woff2) format('woff2');
  unicode-range: U+0301, U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116;
}
/* greek-ext */
@font-face {
  font-family: 'Roboto';
  font-style: normal;
  font-weight: 300;
  font-display: swap;
  src: url(https://img1.wsimg.com/gfonts/s/roboto/v32/KFOlCnqEu92Fr1MmSU5fCBc4EsA.woff2) format('woff2');
  unicode-range: U+1F00-1FFF;
}
/* greek */
@font-face {
  font-family: 'Roboto';
  font-style: normal;
  font-weight: 300;
  font-display: swap;
  src: url(https://img1.wsimg.com/gfonts/s/roboto/v32/KFOlCnqEu92Fr1MmSU5fBxc4EsA.woff2) format('woff2');
  unicode-range: U+0370-0377, U+037A-037F, U+0384-038A, U+038C, U+038E-03A1, U+03A3-03FF;
}
/* vietnamese */
@font-face {
  font-family: 'Roboto';
  font-style: normal;
  font-weight: 300;
  font-display: swap;
  src: url(https://img1.wsimg.com/gfonts/s/roboto/v32/KFOlCnqEu92Fr1MmSU5fCxc4EsA.woff2) format('woff2');
  unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+0300-0301, U+0303-0304, U+0308-0309, U+0323, U+0329, U+1EA0-1EF9, U+20AB;
}
/* latin-ext */
@font-face {
  font-family: 'Roboto';
  font-style: normal;
  font-weight: 300;
  font-display: swap;
  src: url(https://img1.wsimg.com/gfonts/s/roboto/v32/KFOlCnqEu92Fr1MmSU5fChc4EsA.woff2) format('woff2');
  unicode-range: U+0100-02AF, U+0304, U+0308, U+0329, U+1E00-1E9F, U+1EF2-1EFF, U+2020, U+20A0-20AB, U+20AD-20C0, U+2113, U+2C60-2C7F, U+A720-A7FF;
}
/* latin */
@font-face {
  font-family: 'Roboto';
  font-style: normal;
  font-weight: 300;
  font-display: swap;
  src: url(https://img1.wsimg.com/gfonts/s/roboto/v32/KFOlCnqEu92Fr1MmSU5fBBc4.woff2) format('woff2');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+0304, U+0308, U+0329, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}
/* cyrillic-ext */
@font-face {
  font-family: 'Roboto';
  font-style: normal;
  font-weight: 400;
  font-display: swap;
  src: url(https://img1.wsimg.com/gfonts/s/roboto/v32/KFOmCnqEu92Fr1Mu72xKOzY.woff2) format('woff2');
  unicode-range: U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F;
}
/* cyrillic */
@font-face {
  font-family: 'Roboto';
  font-style: normal;
  font-weight: 400;
  font-display: swap;
  src: url(https://img1.wsimg.com/gfonts/s/roboto/v32/KFOmCnqEu92Fr1Mu5mxKOzY.woff2) format('woff2');
  unicode-range: U+0301, U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116;
}
/* greek-ext */
@font-face {
  font-family: 'Roboto';
  font-style: normal;
  font-weight: 400;
  font-display: swap;
  src: url(https://img1.wsimg.com/gfonts/s/roboto/v32/KFOmCnqEu92Fr1Mu7mxKOzY.woff2) format('woff2');
  unicode-range: U+1F00-1FFF;
}
/* greek */
@font-face {
  font-family: 'Roboto';
  font-style: normal;
  font-weight: 400;
  font-display: swap;
  src: url(https://img1.wsimg.com/gfonts/s/roboto/v32/KFOmCnqEu92Fr1Mu4WxKOzY.woff2) format('woff2');
  unicode-range: U+0370-0377, U+037A-037F, U+0384-038A, U+038C, U+038E-03A1, U+03A3-03FF;
}
/* vietnamese */
@font-face {
  font-family: 'Roboto';
  font-style: normal;
  font-weight: 400;
  font-display: swap;
  src: url(https://img1.wsimg.com/gfonts/s/roboto/v32/KFOmCnqEu92Fr1Mu7WxKOzY.woff2) format('woff2');
  unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+0300-0301, U+0303-0304, U+0308-0309, U+0323, U+0329, U+1EA0-1EF9, U+20AB;
}
/* latin-ext */
@font-face {
  font-family: 'Roboto';
  font-style: normal;
  font-weight: 400;
  font-display: swap;
  src: url(https://img1.wsimg.com/gfonts/s/roboto/v32/KFOmCnqEu92Fr1Mu7GxKOzY.woff2) format('woff2');
  unicode-range: U+0100-02AF, U+0304, U+0308, U+0329, U+1E00-1E9F, U+1EF2-1EFF, U+2020, U+20A0-20AB, U+20AD-20C0, U+2113, U+2C60-2C7F, U+A720-A7FF;
}
/* latin */
@font-face {
  font-family: 'Roboto';
  font-style: normal;
  font-weight: 400;
  font-display: swap;
  src: url(https://img1.wsimg.com/gfonts/s/roboto/v32/KFOmCnqEu92Fr1Mu4mxK.woff2) format('woff2');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+0304, U+0308, U+0329, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}
/* cyrillic-ext */
@font-face {
  font-family: 'Roboto';
  font-style: normal;
  font-weight: 700;
  font-display: swap;
  src: url(https://img1.wsimg.com/gfonts/s/roboto/v32/KFOlCnqEu92Fr1MmWUlfCRc4EsA.woff2) format('woff2');
  unicode-range: U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F;
}
/* cyrillic */
@font-face {
  font-family: 'Roboto';
  font-style: normal;
  font-weight: 700;
  font-display: swap;
  src: url(https://img1.wsimg.com/gfonts/s/roboto/v32/KFOlCnqEu92Fr1MmWUlfABc4EsA.woff2) format('woff2');
  unicode-range: U+0301, U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116;
}
/* greek-ext */
@font-face {
  font-family: 'Roboto';
  font-style: normal;
  font-weight: 700;
  font-display: swap;
  src: url(https://img1.wsimg.com/gfonts/s/roboto/v32/KFOlCnqEu92Fr1MmWUlfCBc4EsA.woff2) format('woff2');
  unicode-range: U+1F00-1FFF;
}
/* greek */
@font-face {
  font-family: 'Roboto';
  font-style: normal;
  font-weight: 700;
  font-display: swap;
  src: url(https://img1.wsimg.com/gfonts/s/roboto/v32/KFOlCnqEu92Fr1MmWUlfBxc4EsA.woff2) format('woff2');
  unicode-range: U+0370-0377, U+037A-037F, U+0384-038A, U+038C, U+038E-03A1, U+03A3-03FF;
}
/* vietnamese */
@font-face {
  font-family: 'Roboto';
  font-style: normal;
  font-weight: 700;
  font-display: swap;
  src: url(https://img1.wsimg.com/gfonts/s/roboto/v32/KFOlCnqEu92Fr1MmWUlfCxc4EsA.woff2) format('woff2');
  unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+0300-0301, U+0303-0304, U+0308-0309, U+0323, U+0329, U+1EA0-1EF9, U+20AB;
}
/* latin-ext */
@font-face {
  font-family: 'Roboto';
  font-style: normal;
  font-weight: 700;
  font-display: swap;
  src: url(https://img1.wsimg.com/gfonts/s/roboto/v32/KFOlCnqEu92Fr1MmWUlfChc4EsA.woff2) format('woff2');
  unicode-range: U+0100-02AF, U+0304, U+0308, U+0329, U+1E00-1E9F, U+1EF2-1EFF, U+2020, U+20A0-20AB, U+20AD-20C0, U+2113, U+2C60-2C7F, U+A720-A7FF;
}
/* latin */
@font-face {
  font-family: 'Roboto';
  font-style: normal;
  font-weight: 700;
  font-display: swap;
  src: url(https://img1.wsimg.com/gfonts/s/roboto/v32/KFOlCnqEu92Fr1MmWUlfBBc4.woff2) format('woff2');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+0304, U+0308, U+0329, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}
/* cyrillic-ext */
@font-face {
  font-family: 'Roboto';
  font-style: normal;
  font-weight: 900;
  font-display: swap;
  src: url(https://img1.wsimg.com/gfonts/s/roboto/v32/KFOlCnqEu92Fr1MmYUtfCRc4EsA.woff2) format('woff2');
  unicode-range: U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F;
}
/* cyrillic */
@font-face {
  font-family: 'Roboto';
  font-style: normal;
  font-weight: 900;
  font-display: swap;
  src: url(https://img1.wsimg.com/gfonts/s/roboto/v32/KFOlCnqEu92Fr1MmYUtfABc4EsA.woff2) format('woff2');
  unicode-range: U+0301, U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116;
}
/* greek-ext */
@font-face {
  font-family: 'Roboto';
  font-style: normal;
  font-weight: 900;
  font-display: swap;
  src: url(https://img1.wsimg.com/gfonts/s/roboto/v32/KFOlCnqEu92Fr1MmYUtfCBc4EsA.woff2) format('woff2');
  unicode-range: U+1F00-1FFF;
}
/* greek */
@font-face {
  font-family: 'Roboto';
  font-style: normal;
  font-weight: 900;
  font-display: swap;
  src: url(https://img1.wsimg.com/gfonts/s/roboto/v32/KFOlCnqEu92Fr1MmYUtfBxc4EsA.woff2) format('woff2');
  unicode-range: U+0370-0377, U+037A-037F, U+0384-038A, U+038C, U+038E-03A1, U+03A3-03FF;
}
/* vietnamese */
@font-face {
  font-family: 'Roboto';
  font-style: normal;
  font-weight: 900;
  font-display: swap;
  src: url(https://img1.wsimg.com/gfonts/s/roboto/v32/KFOlCnqEu92Fr1MmYUtfCxc4EsA.woff2) format('woff2');
  unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+0300-0301, U+0303-0304, U+0308-0309, U+0323, U+0329, U+1EA0-1EF9, U+20AB;
}
/* latin-ext */
@font-face {
  font-family: 'Roboto';
  font-style: normal;
  font-weight: 900;
  font-display: swap;
  src: url(https://img1.wsimg.com/gfonts/s/roboto/v32/KFOlCnqEu92Fr1MmYUtfChc4EsA.woff2) format('woff2');
  unicode-range: U+0100-02AF, U+0304, U+0308, U+0329, U+1E00-1E9F, U+1EF2-1EFF, U+2020, U+20A0-20AB, U+20AD-20C0, U+2113, U+2C60-2C7F, U+A720-A7FF;
}
/* latin */
@font-face {
  font-family: 'Roboto';
  font-style: normal;
  font-weight: 900;
  font-display: swap;
  src: url(https://img1.wsimg.com/gfonts/s/roboto/v32/KFOlCnqEu92Fr1MmYUtfBBc4.woff2) format('woff2');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+0304, U+0308, U+0329, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}

/* vietnamese */
@font-face {
  font-family: 'Cabin';
  font-style: italic;
  font-weight: 400;
  font-stretch: 100%;
  font-display: swap;
  src: url(https://img1.wsimg.com/gfonts/s/cabin/v27/u-4V0qWljRw-Pd815fNqc8T_wAFcX-c37MPiNYlWniJ2hJXHx_KVykbvM_s.woff2) format('woff2');
  unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+0300-0301, U+0303-0304, U+0308-0309, U+0323, U+0329, U+1EA0-1EF9, U+20AB;
}
/* latin-ext */
@font-face {
  font-family: 'Cabin';
  font-style: italic;
  font-weight: 400;
  font-stretch: 100%;
  font-display: swap;
  src: url(https://img1.wsimg.com/gfonts/s/cabin/v27/u-4V0qWljRw-Pd815fNqc8T_wAFcX-c37MPiNYlWniJ2hJXHx_KVy0bvM_s.woff2) format('woff2');
  unicode-range: U+0100-02AF, U+0304, U+0308, U+0329, U+1E00-1E9F, U+1EF2-1EFF, U+2020, U+20A0-20AB, U+20AD-20C0, U+2113, U+2C60-2C7F, U+A720-A7FF;
}
/* latin */
@font-face {
  font-family: 'Cabin';
  font-style: italic;
  font-weight: 400;
  font-stretch: 100%;
  font-display: swap;
  src: url(https://img1.wsimg.com/gfonts/s/cabin/v27/u-4V0qWljRw-Pd815fNqc8T_wAFcX-c37MPiNYlWniJ2hJXHx_KVxUbv.woff2) format('woff2');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+0304, U+0308, U+0329, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}
/* vietnamese */
@font-face {
  font-family: 'Cabin';
  font-style: normal;
  font-weight: 400;
  font-stretch: 100%;
  font-display: swap;
  src: url(https://img1.wsimg.com/gfonts/s/cabin/v27/u-4i0qWljRw-PfU81xCKCpdpbgZJl6XvptnsBXw.woff2) format('woff2');
  unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+0300-0301, U+0303-0304, U+0308-0309, U+0323, U+0329, U+1EA0-1EF9, U+20AB;
}
/* latin-ext */
@font-face {
  font-family: 'Cabin';
  font-style: normal;
  font-weight: 400;
  font-stretch: 100%;
  font-display: swap;
  src: url(https://img1.wsimg.com/gfonts/s/cabin/v27/u-4i0qWljRw-PfU81xCKCpdpbgZJl6Xvp9nsBXw.woff2) format('woff2');
  unicode-range: U+0100-02AF, U+0304, U+0308, U+0329, U+1E00-1E9F, U+1EF2-1EFF, U+2020, U+20A0-20AB, U+20AD-20C0, U+2113, U+2C60-2C7F, U+A720-A7FF;
}
/* latin */
@font-face {
  font-family: 'Cabin';
  font-style: normal;
  font-weight: 400;
  font-stretch: 100%;
  font-display: swap;
  src: url(https://img1.wsimg.com/gfonts/s/cabin/v27/u-4i0qWljRw-PfU81xCKCpdpbgZJl6Xvqdns.woff2) format('woff2');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+0304, U+0308, U+0329, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}
/* vietnamese */
@font-face {
  font-family: 'Cabin';
  font-style: normal;
  font-weight: 600;
  font-stretch: 100%;
  font-display: swap;
  src: url(https://img1.wsimg.com/gfonts/s/cabin/v27/u-4i0qWljRw-PfU81xCKCpdpbgZJl6XvptnsBXw.woff2) format('woff2');
  unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+0300-0301, U+0303-0304, U+0308-0309, U+0323, U+0329, U+1EA0-1EF9, U+20AB;
}
/* latin-ext */
@font-face {
  font-family: 'Cabin';
  font-style: normal;
  font-weight: 600;
  font-stretch: 100%;
  font-display: swap;
  src: url(https://img1.wsimg.com/gfonts/s/cabin/v27/u-4i0qWljRw-PfU81xCKCpdpbgZJl6Xvp9nsBXw.woff2) format('woff2');
  unicode-range: U+0100-02AF, U+0304, U+0308, U+0329, U+1E00-1E9F, U+1EF2-1EFF, U+2020, U+20A0-20AB, U+20AD-20C0, U+2113, U+2C60-2C7F, U+A720-A7FF;
}
/* latin */
@font-face {
  font-family: 'Cabin';
  font-style: normal;
  font-weight: 600;
  font-stretch: 100%;
  font-display: swap;
  src: url(https://img1.wsimg.com/gfonts/s/cabin/v27/u-4i0qWljRw-PfU81xCKCpdpbgZJl6Xvqdns.woff2) format('woff2');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+0304, U+0308, U+0329, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}
/* vietnamese */
@font-face {
  font-family: 'Cabin';
  font-style: normal;
  font-weight: 700;
  font-stretch: 100%;
  font-display: swap;
  src: url(https://img1.wsimg.com/gfonts/s/cabin/v27/u-4i0qWljRw-PfU81xCKCpdpbgZJl6XvptnsBXw.woff2) format('woff2');
  unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+0300-0301, U+0303-0304, U+0308-0309, U+0323, U+0329, U+1EA0-1EF9, U+20AB;
}
/* latin-ext */
@font-face {
  font-family: 'Cabin';
  font-style: normal;
  font-weight: 700;
  font-stretch: 100%;
  font-display: swap;
  src: url(https://img1.wsimg.com/gfonts/s/cabin/v27/u-4i0qWljRw-PfU81xCKCpdpbgZJl6Xvp9nsBXw.woff2) format('woff2');
  unicode-range: U+0100-02AF, U+0304, U+0308, U+0329, U+1E00-1E9F, U+1EF2-1EFF, U+2020, U+20A0-20AB, U+20AD-20C0, U+2113, U+2C60-2C7F, U+A720-A7FF;
}
/* latin */
@font-face {
  font-family: 'Cabin';
  font-style: normal;
  font-weight: 700;
  font-stretch: 100%;
  font-display: swap;
  src: url(https://img1.wsimg.com/gfonts/s/cabin/v27/u-4i0qWljRw-PfU81xCKCpdpbgZJl6Xvqdns.woff2) format('woff2');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+0304, U+0308, U+0329, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}
</style><style>.x{-ms-text-size-adjust:100%;-webkit-text-size-adjust:100%;-webkit-tap-highlight-color:rgba(0,0,0,0);margin:0;box-sizing:border-box}.x *,.x :after,.x :before{box-sizing:inherit}.x-el a[href^="mailto:"]:not(.x-el),.x-el a[href^="tel:"]:not(.x-el){color:inherit;font-size:inherit;text-decoration:inherit}.x-el-article,.x-el-aside,.x-el-details,.x-el-figcaption,.x-el-figure,.x-el-footer,.x-el-header,.x-el-hgroup,.x-el-main,.x-el-menu,.x-el-nav,.x-el-section,.x-el-summary{display:block}.x-el-audio,.x-el-canvas,.x-el-progress,.x-el-video{display:inline-block;vertical-align:baseline}.x-el-audio:not([controls]){display:none;height:0}.x-el-template{display:none}.x-el-a{background-color:transparent;color:inherit}.x-el-a:active,.x-el-a:hover{outline:0}.x-el-abbr[title]{border-bottom:1px dotted}.x-el-b,.x-el-strong{font-weight:700}.x-el-dfn{font-style:italic}.x-el-mark{background:#ff0;color:#000}.x-el-small{font-size:80%}.x-el-sub,.x-el-sup{font-size:75%;line-height:0;position:relative;vertical-align:baseline}.x-el-sup{top:-.5em}.x-el-sub{bottom:-.25em}.x-el-img{vertical-align:middle;border:0}.x-el-svg:not(:root){overflow:hidden}.x-el-figure{margin:0}.x-el-hr{box-sizing:content-box;height:0}.x-el-pre{overflow:auto}.x-el-code,.x-el-kbd,.x-el-pre,.x-el-samp{font-family:monospace,monospace;font-size:1em}.x-el-button,.x-el-input,.x-el-optgroup,.x-el-select,.x-el-textarea{color:inherit;font:inherit;margin:0}.x-el-button{overflow:visible}.x-el-button,.x-el-select{text-transform:none}.x-el-button,.x-el-input[type=button],.x-el-input[type=reset],.x-el-input[type=submit]{-webkit-appearance:button;cursor:pointer}.x-el-button[disabled],.x-el-input[disabled]{cursor:default}.x-el-button::-moz-focus-inner,.x-el-input::-moz-focus-inner{border:0;padding:0}.x-el-input{line-height:normal}.x-el-input[type=checkbox],.x-el-input[type=radio]{box-sizing:border-box;padding:0}.x-el-input[type=number]::-webkit-inner-spin-button,.x-el-input[type=number]::-webkit-outer-spin-button{height:auto}.x-el-input[type=search]{-webkit-appearance:textfield;box-sizing:content-box}.x-el-input[type=search]::-webkit-search-cancel-button,.x-el-input[type=search]::-webkit-search-decoration{-webkit-appearance:none}.x-el-textarea{border:0}.x-el-fieldset{border:1px solid silver;margin:0 2px;padding:.35em .625em .75em}.x-el-legend{border:0;padding:0}.x-el-textarea{overflow:auto}.x-el-optgroup{font-weight:700}.x-el-table{border-collapse:collapse;border-spacing:0}.x-el-td,.x-el-th{padding:0}.x{-webkit-font-smoothing:antialiased}.x-el-hr{border:0}.x-el-fieldset,.x-el-input,.x-el-select,.x-el-textarea{margin-top:0;margin-bottom:0}.x-el-fieldset,.x-el-input[type=email],.x-el-input[type=text],.x-el-textarea{width:100%}.x-el-input,.x-el-label{vertical-align:middle}.x-el-input{border-style:none;padding:.5em}.x-el-select:not([multiple]){vertical-align:middle}.x-el-textarea{line-height:1.75;padding:.5em}.x-el.d-none{display:none!important}.sideline-footer{margin-top:auto}.disable-scroll{touch-action:none;overflow:hidden;position:fixed;max-width:100vw}@keyframes loaderscale{0%{transform:scale(1);opacity:1}45%{transform:scale(.1);opacity:.7}80%{transform:scale(1);opacity:1}}.x-loader svg{display:inline-block}.x-loader svg:first-child{animation:loaderscale .75s cubic-bezier(.2,.68,.18,1.08) -.24s infinite}.x-loader svg:nth-child(2){animation:loaderscale .75s cubic-bezier(.2,.68,.18,1.08) -.12s infinite}.x-loader svg:nth-child(3){animation:loaderscale .75s cubic-bezier(.2,.68,.18,1.08) 0s infinite}.x-icon>svg{transition:transform .33s ease-in-out}.x-icon>svg.rotate-90{transform:rotate(-90deg)}.x-icon>svg.rotate90{transform:rotate(90deg)}.x-icon>svg.rotate-180{transform:rotate(-180deg)}.x-icon>svg.rotate180{transform:rotate(180deg)}.x-rt ol,.x-rt ul{text-align:left}.x-rt p{margin:0}.mte-inline-block{display:inline-block}@media only screen and (min-device-width:1025px){:root select,_::-webkit-full-page-media,_:future{font-family:sans-serif!important}}

</style>
<style>/*
Copyright 2011 Google Inc. All Rights Reserved.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/

/*
Copyright 2016 The Cabin Project Authors (impallari@gmail.com)

This Font Software is licensed under the SIL Open Font License, Version 1.1.
This license is copied below, and is also available with a FAQ at: http://scripts.sil.org/OFL

—————————————————————————————-
SIL OPEN FONT LICENSE Version 1.1 - 26 February 2007
—————————————————————————————-
*/
</style>
<style data-glamor="cxs-default-sheet">.x .c1-1{letter-spacing:normal}.x .c1-2{text-transform:none}.x .c1-3{background-color:rgb(255, 255, 255)}.x .c1-4{width:100%}.x .c1-5 > div{position:relative}.x .c1-6 > div{overflow:hidden}.x .c1-7 > div{margin-top:auto}.x .c1-8 > div{margin-right:auto}.x .c1-9 > div{margin-bottom:auto}.x .c1-a > div{margin-left:auto}.x .c1-b{font-family:'Cabin', Georgia, serif}.x .c1-c{font-size:16px}.x .c1-h{background-color:rgb(39, 36, 37)}.x .c1-i{padding-top:56px}.x .c1-j{padding-bottom:56px}.x .c1-k{padding:0px !important}.x .c1-n{position:relative}.x .c1-o{overflow:visible}.x .c1-p{padding-top:8px}.x .c1-q{padding-bottom:8px}.x .c1-r{padding-left:24px}.x .c1-s{padding-right:24px}.x .c1-t{z-index:auto}.x .c1-y{align-items:center}.x .c1-z{flex-wrap:nowrap}.x .c1-10{display:flex}.x .c1-11{margin-top:0px}.x .c1-12{margin-right:0px}.x .c1-13{margin-bottom:0px}.x .c1-14{margin-left:0px}.x .c1-15{[object -object]:0px}.x .c1-17{width:70%}.x .c1-18{text-align:left}.x .c1-19{justify-content:flex-start}.x .c1-1a{overflow-wrap:break-word}.x .c1-1b{padding-left:8px}.x .c1-1c{padding-right:8px}.x .c1-1d{text-transform:unset}.x .c1-1e{font-weight:400}.x .c1-1f{display:inline-block}.x .c1-1g{font-family:'Roboto', arial, sans-serif}.x .c1-1k{letter-spacing:inherit}.x .c1-1l{text-transform:inherit}.x .c1-1m{text-decoration:none}.x .c1-1n{word-wrap:break-word}.x .c1-1o{display:inline}.x .c1-1p{cursor:pointer}.x .c1-1q{border-top:0px}.x .c1-1r{border-right:0px}.x .c1-1s{border-bottom:0px}.x .c1-1t{border-left:0px}.x .c1-1u{max-width:100%}.x .c1-1v{width:auto}.x .c1-1w{color:rgb(255, 255, 255)}.x .c1-1x{font-weight:inherit}.x .c1-1y:hover{color:rgb(198, 198, 198)}.x .c1-1z:active{color:rgb(255, 255, 255)}.x .c1-20{padding-top:0px}.x .c1-21{padding-right:0px}.x .c1-22{padding-bottom:0px}.x .c1-23{padding-left:0px}.x .c1-25{margin-left:auto}.x .c1-26{margin-right:auto}.x .c1-27{vertical-align:middle}.x .c1-28{aspect-ratio:2.3747680890538034 / 1}.x .c1-29{object-fit:contain}.x .c1-2a{height:80px}.x .c1-2b{background-color:transparent}.x .c1-2c{transition:max-height .5s}.x .c1-2d{border-radius:0px}.x .c1-2v{width:30%}.x .c1-2w{justify-content:flex-end}.x .c1-2x{line-height:0}.x .c1-30:hover{color:rgb(255, 255, 255)}.x .c1-31{color:inherit}.x .c1-32{vertical-align:top}.x .c1-33{padding-top:6px}.x .c1-34{padding-right:6px}.x .c1-35{padding-bottom:6px}.x .c1-36{padding-left:6px}.x .c1-3b{display:none}.x .c1-3d{width:35%}.x .c1-3e{min-width:35%}.x .c1-3f{flex-shrink:0}.x .c1-3k{min-width:65%}.x .c1-3l{flex-basis:auto}.x .c1-3n{background-color:rgb(22, 22, 22)}.x .c1-3o{position:fixed}.x .c1-3p{top:0px}.x .c1-3q{height:100%}.x .c1-3r{overflow-y:auto}.x .c1-3s{z-index:10002}.x .c1-3t{-webkit-overflow-scrolling:touch}.x .c1-3u{transform:translateX(-249vw)}.x .c1-3v{overscroll-behavior:contain}.x .c1-3w{box-shadow:0 2px 6px 0px rgba(0,0,0,0.2)}.x .c1-3x{transition:transform .3s ease-in-out}.x .c1-3y{overflow:hidden}.x .c1-3z{flex-direction:column}.x .c1-40{color:rgb(247, 247, 247)}.x .c1-41{line-height:1.3em}.x .c1-42{font-style:normal}.x .c1-43{position:absolute}.x .c1-44{top:15px}.x .c1-45{right:15px}.x .c1-46{font-size:28px}.x .c1-47:hover{color:rgb(127, 128, 128)}.x .c1-4c{overflow-x:hidden}.x .c1-4d{overscroll-behavior:none}.x .c1-4e{-webkit-margin-before:0}.x .c1-4f{-webkit-margin-after:0}.x .c1-4g{-webkit-padding-start:0}.x .c1-4h{display:block}.x .c1-4i{margin-top:60px}.x .c1-4j{margin-bottom:60px}.x .c1-4k{max-width:700px}.x .c1-4l{justify-content:center}.x .c1-4m{align-items:stretch}.x .c1-4n{text-align:center}.x .c1-4p{line-height:1.25}.x .c1-4q{font-size:32px}.x .c1-52{height:auto}.x .c1-53{margin-top:24px}.x .c1-54{line-height:1.5}.x .c1-55{color:rgb(164, 164, 164)}.x .c1-56{font-size:22px}.x .c1-5b{font-size:inherit !important}.x .c1-5c{font-weight:600}.x .c1-5d{line-height:inherit}.x .c1-5e{font-style:italic}.x .c1-5f{text-decoration:line-through}.x .c1-5g{text-decoration:underline}.x .c1-5h{margin-top:32px}.x .c1-5i{letter-spacing:1px}.x .c1-5j{text-transform:uppercase}.x .c1-5k{border-style:none}.x .c1-5l{display:inline-flex}.x .c1-5m{padding-left:40px}.x .c1-5n{padding-right:40px}.x .c1-5o{min-height:56px}.x .c1-5p{border-radius:48px}.x .c1-5q{color:rgb(0, 0, 0)}.x .c1-5r{text-shadow:none}.x .c1-5s{font-size:14px}.x .c1-5t:hover{background-color:rgb(233, 233, 233)}.x .c1-5z{padding-bottom:24px}.x .c1-61{margin-bottom:16px}.x .c1-62{color:rgb(127, 128, 128)}.x .c1-63:hover{color:rgb(194, 190, 191)}.x .c1-64:active{color:rgb(220, 218, 219)}.x .c1-65{box-sizing:border-box}.x .c1-66{flex-direction:row}.x .c1-67{flex-wrap:wrap}.x .c1-68{flex-grow:1}.x .c1-69{flex-shrink:1}.x .c1-6a{flex-basis:100%}.x .c1-6d{color:rgb(169, 169, 169)}.x .c1-6f{margin-top:8px}.x .c1-6h{right:0px}.x .c1-6i{z-index:10000}.x .c1-6j{transition:all 1s ease-in}.x .c1-6k{box-shadow:0 2px 6px 0px rgba(0,0,0,0.3)}.x .c1-6l{contain:content}.x .c1-6m{bottom:-500px}.x .c1-6n{padding-top:24px}.x .c1-6v{max-height:300px}.x .c1-6w{color:rgb(184, 183, 183)}.x .c1-6y{justify-content:space-between}.x .c1-6z{margin-bottom:4px}.x .c1-70{word-break:break-word}.x .c1-71{flex-basis:50%}.x .c1-72{padding-top:4px}.x .c1-73{padding-bottom:4px}.x .c1-74{min-height:40px}.x .c1-75{color:rgb(48, 48, 48)}.x .c1-76{font-size:12px}.x .c1-77:nth-child(2){margin-left:24px}.x .c1-78:hover{background-color:rgb(255, 255, 255)}.x .c1-7d{right:24px}.x .c1-7e{bottom:24px}.x .c1-7f{z-index:9999}.x .c1-7g{width:65px}.x .c1-7h{height:65px}.x .c1-7j{border-radius:50%}.x .c1-7k{box-shadow:0px 3px 18px rgba(0, 0, 0, 0.25)}.x .c1-7l{transform:translateZ(0)}.x .c1-7m{color:rgb(239, 239, 239)}</style>
<style data-glamor="cxs-xs-sheet">@media (max-width: 767px){.x .c1-l{padding-top:40px}}@media (max-width: 767px){.x .c1-m{padding-bottom:40px}}@media (max-width: 767px){.x .c1-1h{justify-content:flex-start}}@media (max-width: 767px){.x .c1-1i{max-width:100%}}@media (max-width: 767px){.x .c1-2e{height:73px}}@media (max-width: 767px){.x .c1-2f{max-width:224px}}@media (max-width: 767px){.x .c1-2g{display:block}}@media (max-width: 767px){.x .c1-2h{max-height:80px}}@media (max-width: 767px){.x .c1-2i{margin-top:0px}}@media (max-width: 767px){.x .c1-2j{margin-right:auto}}@media (max-width: 767px){.x .c1-2k{margin-bottom:0}}@media (max-width: 767px){.x .c1-2l{margin-left:auto}}@media (max-width: 767px){.x .c1-3g{width:100%}}@media (max-width: 767px){.x .c1-3h{display:flex}}@media (max-width: 767px){.x .c1-3i{justify-content:center}}@media (max-width: 767px){.x .c1-60{padding-bottom:32px}}</style>
<style data-glamor="cxs-sm-sheet">@media (min-width: 768px){.x .c1-d{font-size:16px}}@media (min-width: 768px) and (max-width: 1023px){.x .c1-1j{width:auto}}@media (min-width: 768px) and (max-width: 1023px){.x .c1-2m{display:block}}@media (min-width: 768px) and (max-width: 1023px){.x .c1-2n{max-height:80px}}@media (min-width: 768px) and (max-width: 1023px){.x .c1-2o{margin-top:0}}@media (min-width: 768px) and (max-width: 1023px){.x .c1-2p{margin-right:auto}}@media (min-width: 768px) and (max-width: 1023px){.x .c1-2q{margin-bottom:0}}@media (min-width: 768px) and (max-width: 1023px){.x .c1-2r{margin-left:auto}}@media (min-width: 768px){.x .c1-37{width:100%}}@media (min-width: 768px) and (max-width: 1023px){.x .c1-3j{width:100%}}@media (min-width: 768px){.x .c1-48{font-size:30px}}@media (min-width: 768px){.x .c1-4o{min-height:300px}}@media (min-width: 768px){.x .c1-4r{font-size:38px}}@media (min-width: 768px){.x .c1-57{font-size:22px}}@media (min-width: 768px){.x .c1-5u{width:auto}}@media (min-width: 768px){.x .c1-5v{font-size:14px}}@media (min-width: 768px){.x .c1-6o{width:400px}}@media (min-width: 768px){.x .c1-6p{max-height:500px}}@media (min-width: 768px){.x .c1-6q{border-radius:7px}}@media (min-width: 768px){.x .c1-6r{margin-top:24px}}@media (min-width: 768px){.x .c1-6s{margin-right:24px}}@media (min-width: 768px){.x .c1-6t{margin-bottom:24px}}@media (min-width: 768px){.x .c1-6u{margin-left:24px}}@media (min-width: 768px){.x .c1-6x{max-height:200px}}@media (min-width: 768px){.x .c1-79{font-size:12px}}</style>
<style data-glamor="cxs-md-sheet">@media (min-width: 1024px){.x .c1-e{font-size:16px}}@media (min-width: 1024px){.x .c1-u{padding-top:16px}}@media (min-width: 1024px){.x .c1-v{padding-bottom:16px}}@media (min-width: 1024px){.x .c1-w{padding-left:0px}}@media (min-width: 1024px){.x .c1-x{padding-right:0px}}@media (min-width: 1024px){.x .c1-16{display:none}}@media (min-width: 1024px){.x .c1-24{display:inline-block}}@media (min-width: 1024px){.x .c1-2s{height:73px}}@media (min-width: 1024px){.x .c1-2t{width:auto}}@media (min-width: 1024px){.x .c1-2u{max-height:73px}}@media (min-width: 1024px){.x .c1-2y > :first-child{margin-left:24px}}@media (min-width: 1024px){.x .c1-2z{justify-content:inherit}}@media (min-width: 1024px){.x .c1-38{width:984px}}@media (min-width: 1024px){.x .c1-3c{display:flex}}@media (min-width: 1024px){.x .c1-3m > :first-child{margin-left:0px}}@media (min-width: 1024px){.x .c1-49{font-size:30px}}@media (min-width: 1024px){.x .c1-4s{text-align:center}}@media (min-width: 1024px){.x .c1-4t{padding-top:0px}}@media (min-width: 1024px){.x .c1-4u{padding-bottom:0px}}@media (min-width: 1024px){.x .c1-4v{margin-top:0px}}@media (min-width: 1024px){.x .c1-4w{margin-right:0px}}@media (min-width: 1024px){.x .c1-4x{margin-bottom:0px}}@media (min-width: 1024px){.x .c1-4y{margin-left:0px}}@media (min-width: 1024px){.x .c1-4z{font-size:38px}}@media (min-width: 1024px){.x .c1-58{font-size:22px}}@media (min-width: 1024px){.x .c1-5w{font-size:14px}}@media (min-width: 1024px){.x .c1-6b{flex-basis:0%}}@media (min-width: 1024px){.x .c1-6c{max-width:none}}@media (min-width: 1024px){.x .c1-6e{text-align:left}}@media (min-width: 1024px){.x .c1-6g{text-align:right}}@media (min-width: 1024px){.x .c1-7a{font-size:12px}}@media (min-width: 1024px){.x .c1-7i{z-index:9999}}</style>
<style data-glamor="cxs-lg-sheet">@media (min-width: 1280px){.x .c1-f{font-size:16px}}@media (min-width: 1280px){.x .c1-39{width:1160px}}@media (min-width: 1280px){.x .c1-4a{font-size:32px}}@media (min-width: 1280px){.x .c1-50{font-size:44px}}@media (min-width: 1280px){.x .c1-59{font-size:22px}}@media (min-width: 1280px){.x .c1-5x{font-size:14px}}@media (min-width: 1280px){.x .c1-7b{font-size:12px}}</style>
<style data-glamor="cxs-xl-sheet">@media (min-width: 1536px){.x .c1-g{font-size:18px}}@media (min-width: 1536px){.x .c1-3a{width:1280px}}@media (min-width: 1536px){.x .c1-4b{font-size:36px}}@media (min-width: 1536px){.x .c1-51{font-size:48px}}@media (min-width: 1536px){.x .c1-5a{font-size:24px}}@media (min-width: 1536px){.x .c1-5y{font-size:16px}}@media (min-width: 1536px){.x .c1-7c{font-size:14px}}</style>
<style>@keyframes opacity-bounce { 
      0% {opacity: 0;transform: translateY(100%); } 
      60% { transform: translateY(-20%); } 
      100% { opacity: 1; transform: translateY(0); }
    }</style>
<style>.gd-ad-flex-parent {
          animation-name: opacity-bounce; 
          animation-duration: 800ms; 
          animation-delay: 400ms; 
          animation-fill-mode: forwards; 
          animation-timing-function: ease; 
          opacity: 0;</style>
<style>.page-inner { background-color: rgb(22, 22, 22); min-height: 100vh; }</style>
<style>.grecaptcha-badge { visibility: hidden; }</style>
<script>"use strict";

if ('serviceWorker' in navigator) {
  window.addEventListener('load', function () {
    navigator.serviceWorker.register('/sw.js');
  });
}</script></head>
<body class="x  x-fonts-roboto x-fonts-cabin"><div id="layout-66-f-40-e-72-7-c-50-49-d-9-aa-9-b-3-b-320019-d-517" class="layout layout-layout layout-layout-layout-10 locale-en-IN lang-en"><div data-ux="Page" id="page-4472" class="x-el x-el-div x-el c1-1 c1-2 c1-3 c1-4 c1-5 c1-6 c1-7 c1-8 c1-9 c1-a c1-b c1-c c1-d c1-e c1-f c1-g c1-1 c1-2 c1-b c1-c c1-d c1-e c1-f c1-g"><div data-ux="Block" class="x-el x-el-div page-inner c1-1 c1-2 c1-b c1-c c1-d c1-e c1-f c1-g"><div id="09933d2f-84d1-4d8a-88f1-1a3af200f625" class="widget widget-header widget-header-header-9"><div data-ux="Header" role="main" data-aid="HEADER_WIDGET" id="n-4473" class="x-el x-el-div x-el x-el c1-1 c1-2 c1-b c1-c c1-d c1-e c1-f c1-g c1-1 c1-2 c1-h c1-b c1-c c1-d c1-e c1-f c1-g c1-1 c1-2 c1-b c1-c c1-d c1-e c1-f c1-g"><div> <div id="freemium-ad-4475"></div><section data-ux="Section" data-aid="HEADER_SECTION" class="x-el x-el-section c1-1 c1-2 c1-h c1-i c1-j c1-k c1-b c1-c c1-l c1-m c1-d c1-e c1-f c1-g"><div data-ux="Block" class="x-el x-el-div c1-1 c1-2 c1-n c1-o c1-b c1-c c1-d c1-e c1-f c1-g"><div data-ux="Block" class="x-el x-el-div c1-1 c1-2 c1-h c1-b c1-c c1-d c1-e c1-f c1-g"><nav data-ux="Block" class="x-el x-el-nav c1-1 c1-2 c1-n c1-p c1-q c1-r c1-s c1-h c1-t c1-b c1-c c1-d c1-u c1-v c1-w c1-x c1-e c1-f c1-g"><div data-ux="Block" class="x-el x-el-div c1-1 c1-2 c1-y c1-z c1-4 c1-10 c1-11 c1-12 c1-13 c1-14 c1-15 c1-b c1-c c1-d c1-16 c1-e c1-f c1-g"><div data-ux="Block" class="x-el x-el-div c1-1 c1-2 c1-10 c1-17 c1-18 c1-19 c1-1a c1-1b c1-1c c1-b c1-c c1-d c1-e c1-f c1-g"><div data-ux="Block" data-aid="HEADER_LOGO_RENDERED" class="x-el x-el-div c1-1 c1-1d c1-1e c1-1f c1-1g c1-c c1-1h c1-1i c1-1j c1-d c1-e c1-f c1-g"><a rel="" role="link" aria-haspopup="menu" data-ux="Link" data-page="2ba86f30-cc21-4237-a988-6869a204ea90" title="Dezykode" href="/" data-typography="LinkAlpha" class="x-el x-el-a c1-1k c1-1l c1-1m c1-1n c1-1a c1-1o c1-1p c1-1q c1-1r c1-1s c1-1t c1-1u c1-1v c1-b c1-1w c1-c c1-1x c1-1y c1-1z c1-d c1-e c1-f c1-g" data-tccl="ux2.HEADER.header9.Logo.Default.Link.Default.4478.click,click"><div data-ux="Block" class="x-el x-el-div c1-1 c1-2 c1-20 c1-21 c1-22 c1-23 c1-15 c1-b c1-c c1-d c1-24 c1-e c1-f c1-g"><img src="//img1.wsimg.com/isteam/ip/66f40e72-7c50-49d9-aa9b-3b320019d517/Logo%20n%20name.jpg/:/rs=h:73,cg:true,m/qt=q:95" srcSet="//img1.wsimg.com/isteam/ip/66f40e72-7c50-49d9-aa9b-3b320019d517/Logo%20n%20name.jpg/:/rs=w:173,h:73,cg:true,m/cr=w:173,h:73/qt=q:95, //img1.wsimg.com/isteam/ip/66f40e72-7c50-49d9-aa9b-3b320019d517/Logo%20n%20name.jpg/:/rs=w:347,h:146,cg:true,m/cr=w:347,h:146/qt=q:95 2x, //img1.wsimg.com/isteam/ip/66f40e72-7c50-49d9-aa9b-3b320019d517/Logo%20n%20name.jpg/:/rs=w:520,h:219,cg:true,m/cr=w:520,h:219/qt=q:95 3x" alt="Dezykode" data-ux="ImageLogo" data-aid="HEADER_LOGO_IMAGE_RENDERED" class="x-el x-el-img c1-1 c1-2 c1-4 c1-1u c1-25 c1-26 c1-11 c1-13 c1-27 c1-28 c1-29 c1-2a c1-2b c1-2c c1-20 c1-21 c1-22 c1-23 c1-2d c1-15 c1-b c1-c c1-2e c1-2f c1-2g c1-2h c1-2i c1-2j c1-2k c1-2l c1-2m c1-2n c1-2o c1-2p c1-2q c1-2r c1-d c1-2s c1-2t c1-2u c1-e c1-f c1-g"/></div></a></div></div><div data-ux="Block" class="x-el x-el-div c1-1 c1-2 c1-2v c1-21 c1-23 c1-10 c1-2w c1-b c1-c c1-d c1-e c1-f c1-g"><div data-ux="UtilitiesMenu" id="membership14479-utility-menu" class="x-el x-el-div c1-1 c1-2 c1-10 c1-y c1-2x c1-b c1-c c1-2w c1-d c1-2y c1-2z c1-e c1-f c1-g"><span data-ux="Element" class="x-el x-el-span c1-1 c1-2 c1-b c1-c c1-d c1-e c1-f c1-g"><div data-ux="Element" id="bs-1" class="x-el x-el-div c1-1 c1-2 c1-1f c1-b c1-c c1-d c1-e c1-f c1-g"></div></span></div><div data-ux="Element" id="bs-2" class="x-el x-el-div c1-1 c1-2 c1-b c1-c c1-d c1-e c1-f c1-g"><a rel="" role="button" aria-haspopup="menu" data-ux="LinkDropdown" data-toggle-ignore="true" id="4480" aria-expanded="false" toggleId="n-4473-navId-mobile" icon="hamburger" data-edit-interactive="true" data-aid="HAMBURGER_MENU_LINK" aria-label="Hamburger Site Navigation Icon" href="#" data-typography="LinkAlpha" class="x-el x-el-a c1-1k c1-1l c1-1m c1-1n c1-1a c1-10 c1-1p c1-y c1-19 c1-1q c1-1r c1-1s c1-1t c1-1w c1-b c1-c c1-1x c1-30 c1-1z c1-d c1-16 c1-e c1-f c1-g" data-tccl="ux2.HEADER.header9.Section.Default.Link.Dropdown.4481.click,click"><svg viewBox="0 0 24 24" fill="currentColor" width="40px" height="40px" data-ux="IconHamburger" class="x-el x-el-svg c1-1 c1-2 c1-31 c1-1f c1-32 c1-33 c1-34 c1-35 c1-36 c1-b c1-c c1-d c1-e c1-f c1-g"><g><path fill-rule="evenodd" d="M4 8h16V6H4z"></path><path fill-rule="evenodd" d="M4 13.096h16v-2.001H4z"></path><path fill-rule="evenodd" d="M4 18.346h16v-2H4z"></path></g></svg></a></div></div></div><div data-ux="Container" class="x-el x-el-div c1-1 c1-2 c1-25 c1-26 c1-r c1-s c1-1u c1-b c1-c c1-37 c1-d c1-38 c1-e c1-39 c1-f c1-3a c1-g"><div data-ux="Block" id="navBarId-4483" class="x-el x-el-div c1-1 c1-2 c1-3b c1-19 c1-y c1-z c1-20 c1-22 c1-b c1-c c1-d c1-3c c1-e c1-f c1-g"><div data-ux="Block" class="x-el x-el-div c1-1 c1-2 c1-21 c1-10 c1-y c1-19 c1-3d c1-3e c1-3f c1-b c1-c c1-d c1-e c1-f c1-g"><div data-ux="Block" data-aid="HEADER_LOGO_RENDERED" class="x-el x-el-div c1-1 c1-1d c1-1e c1-1f c1-1g c1-18 c1-c c1-3g c1-3h c1-3i c1-3j c1-d c1-e c1-f c1-g"><a rel="" role="link" aria-haspopup="menu" data-ux="Link" data-page="2ba86f30-cc21-4237-a988-6869a204ea90" title="Dezykode" href="/" data-typography="LinkAlpha" class="x-el x-el-a c1-1k c1-1l c1-1m c1-1n c1-1a c1-1o c1-1p c1-1q c1-1r c1-1s c1-1t c1-1u c1-1v c1-b c1-1w c1-c c1-1x c1-1y c1-1z c1-d c1-e c1-f c1-g" data-tccl="ux2.HEADER.header9.Logo.Default.Link.Default.4484.click,click"><div data-ux="Block" class="x-el x-el-div c1-1 c1-2 c1-20 c1-21 c1-22 c1-23 c1-15 c1-b c1-c c1-d c1-24 c1-e c1-f c1-g"><img src="//img1.wsimg.com/isteam/ip/66f40e72-7c50-49d9-aa9b-3b320019d517/Logo%20n%20name.jpg/:/rs=h:73,cg:true,m/qt=q:95" srcSet="//img1.wsimg.com/isteam/ip/66f40e72-7c50-49d9-aa9b-3b320019d517/Logo%20n%20name.jpg/:/rs=w:173,h:73,cg:true,m/cr=w:173,h:73/qt=q:95, //img1.wsimg.com/isteam/ip/66f40e72-7c50-49d9-aa9b-3b320019d517/Logo%20n%20name.jpg/:/rs=w:347,h:146,cg:true,m/cr=w:347,h:146/qt=q:95 2x, //img1.wsimg.com/isteam/ip/66f40e72-7c50-49d9-aa9b-3b320019d517/Logo%20n%20name.jpg/:/rs=w:520,h:219,cg:true,m/cr=w:520,h:219/qt=q:95 3x" alt="Dezykode" data-ux="ImageLogo" data-aid="HEADER_LOGO_IMAGE_RENDERED" id="logo-4482" class="x-el x-el-img c1-1 c1-2 c1-4 c1-1u c1-25 c1-26 c1-11 c1-13 c1-27 c1-28 c1-29 c1-2a c1-2b c1-2c c1-20 c1-21 c1-22 c1-23 c1-2d c1-15 c1-b c1-c c1-2e c1-2f c1-2g c1-2h c1-2i c1-2j c1-2k c1-2l c1-2m c1-2n c1-2o c1-2p c1-2q c1-2r c1-d c1-2s c1-2t c1-2u c1-e c1-f c1-g"/></div></a></div></div><div data-ux="Block" class="x-el x-el-div c1-1 c1-2 c1-10 c1-3k c1-y c1-3l c1-2w c1-b c1-c c1-d c1-e c1-f c1-g"><div data-ux="Block" class="x-el x-el-div c1-1 c1-2 c1-10 c1-n c1-b c1-c c1-d c1-e c1-f c1-g"><div data-ux="UtilitiesMenu" id="n-44734485-utility-menu" class="x-el x-el-div c1-1 c1-2 c1-10 c1-y c1-2x c1-b c1-c c1-2w c1-d c1-3m c1-2z c1-e c1-f c1-g"><span data-ux="Element" class="x-el x-el-span c1-1 c1-2 c1-b c1-c c1-d c1-e c1-f c1-g"><div data-ux="Element" id="bs-3" class="x-el x-el-div c1-1 c1-2 c1-1f c1-b c1-c c1-d c1-e c1-f c1-g"></div></span></div></div></div></div></div></nav></div><div role="navigation" data-ux="NavigationDrawer" id="n-4473-navId-mobile" class="x-el x-el-div c1-1 c1-2 c1-3n c1-3o c1-3p c1-4 c1-3q c1-3r c1-3s c1-i c1-3t c1-3u c1-3v c1-3w c1-3x c1-3y c1-10 c1-3z c1-b c1-c c1-d c1-e c1-f c1-g"><div data-ux="Block" class="x-el x-el-div c1-1 c1-2 c1-r c1-s c1-b c1-c c1-d c1-e c1-f c1-g"><svg viewBox="0 0 24 24" fill="currentColor" width="40px" height="40px" data-ux="CloseIcon" data-edit-interactive="true" data-close="true" class="x-el x-el-svg c1-1 c1-2 c1-40 c1-1f c1-27 c1-33 c1-34 c1-35 c1-36 c1-1p c1-41 c1-42 c1-43 c1-44 c1-45 c1-46 c1-b c1-47 c1-48 c1-49 c1-4a c1-4b"><path fill-rule="evenodd" d="M17.999 4l-6.293 6.293L5.413 4 4 5.414l6.292 6.293L4 18l1.413 1.414 6.293-6.292 6.293 6.292L19.414 18l-6.294-6.293 6.294-6.293z"></path></svg></div><div data-ux="Container" id="n-4473-navContainerId-mobile" class="x-el x-el-div c1-1 c1-2 c1-25 c1-26 c1-r c1-s c1-1u c1-3r c1-4c c1-4 c1-4d c1-b c1-c c1-37 c1-d c1-38 c1-e c1-39 c1-f c1-3a c1-g"><div data-ux="Block" id="n-4473-navLinksContentId-mobile" class="x-el x-el-div c1-1 c1-2 c1-b c1-c c1-d c1-e c1-f c1-g"><ul role="menu" data-ux="NavigationDrawerList" id="n-4473-navListId-mobile" class="x-el x-el-ul c1-1 c1-2 c1-11 c1-13 c1-14 c1-12 c1-4e c1-4f c1-4g c1-18 c1-20 c1-22 c1-23 c1-21 c1-1n c1-1a c1-b c1-c c1-d c1-e c1-f c1-g"></ul><div data-ux="Block" class="x-el x-el-div c1-1 c1-2 c1-b c1-c c1-4h c1-d c1-16 c1-e c1-f c1-g"></div></div></div></div></div></section>  </div></div></div><div id="a10dc4a8-c4c8-431e-9613-3c4b8cc1335c" class="widget widget-introduction widget-introduction-introduction-3"><div data-ux="Widget" role="region" id="a10dc4a8-c4c8-431e-9613-3c4b8cc1335c" class="x-el x-el-div x-el c1-1 c1-2 c1-3n c1-b c1-c c1-d c1-e c1-f c1-g c1-1 c1-2 c1-b c1-c c1-d c1-e c1-f c1-g"><div> <section data-ux="Section" class="x-el x-el-section c1-1 c1-2 c1-3n c1-i c1-j c1-b c1-c c1-l c1-m c1-d c1-e c1-f c1-g"><div data-ux="Container" align="center" class="x-el x-el-div c1-1 c1-2 c1-25 c1-26 c1-r c1-s c1-1u c1-b c1-c c1-37 c1-d c1-38 c1-e c1-39 c1-f c1-3a c1-g"><div data-ux="Block" class="x-el x-el-div c1-1 c1-2 c1-4i c1-4j c1-4k c1-b c1-c c1-2i c1-1i c1-d c1-e c1-f c1-g"><div data-ux="VerticalBox" class="x-el x-el-div x-el c1-1 c1-2 c1-3q c1-1v c1-10 c1-4l c1-4m c1-3z c1-4n c1-b c1-c c1-4o c1-d c1-e c1-f c1-g c1-1 c1-2 c1-b c1-c c1-d c1-e c1-f c1-g"><div data-ux="Group" class="x-el x-el-div c1-1 c1-2 c1-b c1-c c1-d c1-e c1-f c1-g"><h1 role="heading" aria-level="1" data-ux="HeadingMajor" data-aid="SECTION_TITLE_RENDERED" data-promoted-from="2" data-order="0" data-typography="HeadingBeta" class="x-el x-el-h1 c1-1 c1-1d c1-1e c1-1n c1-1a c1-4p c1-14 c1-12 c1-11 c1-13 c1-4n c1-40 c1-20 c1-21 c1-22 c1-23 c1-1g c1-4q c1-15 c1-4r c1-4s c1-4t c1-x c1-4u c1-w c1-4v c1-4w c1-4x c1-4y c1-4z c1-50 c1-51">Page Not Found</h1><div data-ux="HorizontalBox" class="x-el x-el-div x-el c1-1 c1-2 c1-52 c1-4 c1-10 c1-4l c1-4m c1-53 c1-b c1-c c1-d c1-e c1-f c1-g c1-1 c1-2 c1-b c1-c c1-d c1-e c1-f c1-g"><div data-ux="Text" data-aid="DESCRIPTION_TEXT" data-typography="BodyBeta" class="x-el c1-1 c1-2 c1-1n c1-1a c1-54 c1-11 c1-13 c1-1u c1-b c1-55 c1-56 c1-1e c1-57 c1-58 c1-59 c1-5a x-rt"><p style="margin:0"><span>We can’t seem to find the page you’re looking for.</span></p></div></div><div data-ux="Block" class="x-el x-el-div c1-1 c1-2 c1-5h c1-b c1-c c1-d c1-e c1-f c1-g"><a data-ux-btn="secondary" data-ux="ButtonSecondary" shape="PILL" decoration="NONE" shadow="NONE" data-aid="CTA_BUTTON_RENDERED" href="/" target="" data-tccl="pandc.vnext.404.cta.click,click" data-page="2ba86f30-cc21-4237-a988-6869a204ea90" color="HIGHCONTRAST" data-typography="ButtonAlpha" class="x-el x-el-a c1-5i c1-5j c1-1p c1-5k c1-5l c1-y c1-4l c1-4n c1-1m c1-1a c1-1n c1-n c1-1u c1-4 c1-5m c1-5n c1-p c1-q c1-5o c1-5p c1-5q c1-3 c1-b c1-5c c1-5r c1-5s c1-5t c1-5u c1-5v c1-5w c1-5x c1-5y">Go To Home Page</a></div></div></div></div></div></section>  </div></div></div><div id="a068cb93-7d54-497b-9c83-3d5e1a8b7bac" class="widget widget-footer widget-footer-footer-4"><div data-ux="Widget" role="contentinfo" id="a068cb93-7d54-497b-9c83-3d5e1a8b7bac" class="x-el x-el-div x-el c1-1 c1-2 c1-3n c1-b c1-c c1-d c1-e c1-f c1-g c1-1 c1-2 c1-b c1-c c1-d c1-e c1-f c1-g"><div> <section data-ux="Section" class="x-el x-el-section c1-1 c1-2 c1-3n c1-i c1-j c1-b c1-c c1-l c1-m c1-d c1-e c1-f c1-g"><div data-ux="Container" class="x-el x-el-div c1-1 c1-2 c1-25 c1-26 c1-r c1-s c1-1u c1-b c1-c c1-37 c1-d c1-38 c1-e c1-39 c1-f c1-3a c1-g"><div data-ux="Layout" class="x-el x-el-div c1-1 c1-2 c1-4n c1-b c1-c c1-d c1-e c1-f c1-g"><div data-ux="Container" class="x-el x-el-div c1-1 c1-2 c1-25 c1-26 c1-r c1-s c1-1u c1-5z c1-b c1-c c1-60 c1-37 c1-d c1-38 c1-e c1-39 c1-f c1-3a c1-g"><p data-ux="FooterText" data-aid="FOOTER_BUSINESS_NAME_RENDERED" data-typography="BodyAlpha" class="x-el x-el-p c1-1 c1-2 c1-1n c1-1a c1-54 c1-11 c1-61 c1-5c c1-b c1-40 c1-c c1-d c1-e c1-f c1-g">Dezykode IT Solutions Pvt Ltd -  Pune</p><p data-ux="FooterText" data-aid="FOOTER_ADDRESS_RENDERED" data-typography="BodyAlpha" class="x-el x-el-p c1-1 c1-2 c1-1n c1-1a c1-54 c1-11 c1-61 c1-b c1-40 c1-c c1-1e c1-d c1-e c1-f c1-g">City Vista, Kharadi, A Wing, 08, Second Floor, Fountain Road, Ashoka Nagar, Kharadi, Pune, Maharashtra, India. E-Mail: dezykode@gmail.com</p><p data-ux="FooterText" data-aid="FOOTER_PHONE_RENDERED" data-typography="BodyAlpha" class="x-el x-el-p c1-1 c1-2 c1-1n c1-1a c1-54 c1-11 c1-13 c1-b c1-40 c1-c c1-1e c1-d c1-e c1-f c1-g">Connect @ <a rel="" role="link" aria-haspopup="false" data-ux="Link" href="tel:9730822219" data-typography="LinkAlpha" class="x-el x-el-a c1-1k c1-1l c1-1m c1-1n c1-1a c1-1o c1-1p c1-b c1-62 c1-c c1-1x c1-63 c1-64 c1-d c1-e c1-f c1-g" data-tccl="ux2.FOOTER.footer4.Layout.Default.Link.Default.4486.click,click">9730822219</a></p></div><div data-ux="Grid" class="x-el x-el-div c1-1 c1-2 c1-10 c1-65 c1-66 c1-67 c1-11 c1-12 c1-13 c1-14 c1-y c1-4n c1-b c1-c c1-d c1-e c1-f c1-g"><div data-ux="GridCell" class="x-el x-el-div c1-1 c1-2 c1-65 c1-68 c1-69 c1-6a c1-1u c1-20 c1-21 c1-22 c1-23 c1-b c1-c c1-d c1-6b c1-6c c1-e c1-f c1-g"><div data-ux="FooterDetails" data-aid="FOOTER_COPYRIGHT_RENDERED" data-typography="DetailsAlpha" class="x-el c1-1 c1-2 c1-1n c1-1a c1-54 c1-11 c1-13 c1-b c1-6d c1-5s c1-1e c1-5v c1-6e c1-5w c1-5x c1-5y x-rt"><p style="margin:0"><span>Copyright © 2024 Dezykode - All Rights Reserved.</span></p></div></div><div data-ux="GridCell" class="x-el x-el-div c1-1 c1-2 c1-65 c1-68 c1-69 c1-6a c1-1u c1-20 c1-21 c1-22 c1-23 c1-b c1-c c1-d c1-6b c1-6c c1-e c1-f c1-g"><p data-ux="FooterDetails" data-aid="FOOTER_POWERED_BY_RENDERED" data-typography="DetailsAlpha" class="x-el x-el-p c1-1 c1-2 c1-1n c1-1a c1-54 c1-6f c1-13 c1-b c1-6d c1-5s c1-1e c1-5v c1-6g c1-4v c1-5w c1-5x c1-5y"><span>Powered by Dezykode</span></p></div></div></div></div></section>  </div></div></div><div id="31c52bd9-df30-4b2e-b127-0aac809a1ccc" class="widget widget-cookie-banner widget-cookie-banner-cookie-1"><div data-ux="Group" data-aid="FOOTER_COOKIE_BANNER_RENDERED" id="31c52bd9-df30-4b2e-b127-0aac809a1ccc-banner" class="x-el x-el-div c1-1 c1-2 c1-3o c1-6h c1-6i c1-4 c1-52 c1-18 c1-h c1-2d c1-3r c1-6j c1-6k c1-6l c1-6m c1-6n c1-s c1-5z c1-r c1-11 c1-12 c1-13 c1-14 c1-15 c1-b c1-c c1-6o c1-6p c1-6q c1-6r c1-6s c1-6t c1-6u c1-d c1-e c1-f c1-g"><h4 role="heading" aria-level="4" data-ux="Heading" data-aid="FOOTER_COOKIE_TITLE_RENDERED" data-typography="HeadingDelta" class="x-el x-el-h4 c1-1 c1-2 c1-1n c1-1a c1-4p c1-14 c1-12 c1-11 c1-13 c1-q c1-b c1-1w c1-56 c1-1e c1-57 c1-58 c1-59 c1-5a">This website uses cookies.</h4><div data-ux="Text" data-aid="FOOTER_COOKIE_MESSAGE_RENDERED" data-typography="BodyAlpha" class="x-el c1-1 c1-2 c1-1n c1-1a c1-54 c1-11 c1-13 c1-6v c1-3r c1-b c1-6w c1-c c1-1e c1-6x c1-d c1-e c1-f c1-g x-rt"><p style="margin:0"><span>We use cookies to analyze website traffic and optimize your website experience. By accepting our use of cookies, your data will be aggregated with all other user data.</span></p></div><div data-ux="Block" class="x-el x-el-div c1-1 c1-2 c1-10 c1-6y c1-b c1-c c1-d c1-e c1-f c1-g"><a data-ux-btn="primary" data-ux="ButtonPrimary" color="PRIMARY" fill="SOLID" shape="PILL" decoration="NONE" shadow="NONE" href="" data-aid="FOOTER_COOKIE_CLOSE_RENDERED" id="31c52bd9-df30-4b2e-b127-0aac809a1ccc-accept" data-typography="ButtonAlpha" class="x-el x-el-a c1-5i c1-5j c1-10 c1-3z c1-4l c1-1p c1-53 c1-6z c1-70 c1-71 c1-68 c1-5k c1-y c1-4n c1-1m c1-1a c1-1n c1-n c1-1u c1-4 c1-r c1-s c1-72 c1-73 c1-74 c1-5p c1-75 c1-3 c1-b c1-5c c1-5r c1-76 c1-77 c1-78 c1-5u c1-79 c1-7a c1-7b c1-7c" data-tccl="ux2.COOKIE_BANNER.cookie1.Group.Default.Button.Primary.4487.click,click">Accept</a></div></div></div><div id="5e165850-3a30-4127-96ba-6187301eb27d" class="widget widget-popup widget-popup-popup-1"></div><div id="c013a9dc-ac53-449a-b5fc-d077ada30e67" class="widget widget-messaging widget-messaging-messaging-1"><div data-ux="Element" id="bs-4" class="x-el x-el-div c1-1 c1-2 c1-b c1-c c1-d c1-e c1-f c1-g"><div data-ux="Block" class="x-el x-el-div c1-1 c1-2 c1-3o c1-7d c1-7e c1-7f c1-7g c1-7h c1-b c1-c c1-d c1-7i c1-e c1-f c1-g"><div data-ux="Block" data-aid="MESSAGING_FAB" data-edit-interactive="true" data-traffic2="pandc.vnext.editor_preview.messaging_fab_open.click" data-tccl="ux2.messaging.fab.open,click" class="x-el x-el-div c1-1 c1-2 c1-10 c1-y c1-4l c1-1p c1-4 c1-3q c1-7j c1-h c1-7k c1-7l c1-b c1-c c1-d c1-e c1-f c1-g"><svg viewBox="0 0 24 24" fill="currentColor" width="44" height="44" data-ux="Icon" class="x-el x-el-svg c1-1 c1-2 c1-7m c1-1f c1-27 c1-b c1-c c1-d c1-e c1-f c1-g"><g fill="currentColor"><rect x="4" y="6" width="16" height="10.222" rx="1.129"></rect><path d="M8.977 18.578l.2-2.722a.564.564 0 01.564-.523h3.61c.548 0 .774.705.327 1.024l-3.81 2.721a.564.564 0 01-.89-.5z"></path></g></svg></div></div></div></div></div></div></div>
<script src="//img1.wsimg.com/blobby/go/66f40e72-7c50-49d9-aa9b-3b320019d517/gpub/4037cfcef60010ab/script.js" crossorigin></script>
<script src="//img1.wsimg.com/ceph-p3-01/website-builder-data-prod/static/widgets/UX.4.43.0.js" crossorigin></script>
<script src="//img1.wsimg.com/blobby/go/66f40e72-7c50-49d9-aa9b-3b320019d517/gpub/c56e27213bf917cf/script.js" crossorigin></script>
<script async src="https://www.googletagmanager.com/gtag/js?id=G-BF2FDR6KMM" crossorigin></script>
<script>"use strict";Core.utils.onAllowCookieTracking(() => {var _window$dataLayer, _window$dataLayer$, _window$dataLayer2, _window$dataLayer2$;window.dataLayer && Array.isArray(window.dataLayer) && ((_window$dataLayer = window.dataLayer) === null || _window$dataLayer === void 0 ? void 0 : (_window$dataLayer$ = _window$dataLayer[0]) === null || _window$dataLayer$ === void 0 ? void 0 : _window$dataLayer$[0]) === "consent" && ((_window$dataLayer2 = window.dataLayer) === null || _window$dataLayer2 === void 0 ? void 0 : (_window$dataLayer2$ = _window$dataLayer2[0]) === null || _window$dataLayer2$ === void 0 ? void 0 : _window$dataLayer2$[1]) === "default" && (window.gtag = window.gtag || function () {window.dataLayer.push(arguments);}, window.gtag("consent", "update", {ad_user_data: "granted",ad_personalization: "granted",ad_storage: "granted",analytics_storage: "granted"}));});
"use strict";window.gtag = window.gtag || function () {window.dataLayer.push(arguments);}, gtag("js", new Date()), gtag("set", "developer_id.dZTZmYj", !0);
"use strict";window._commercegaID = "G-BF2FDR6KMM", gtag("config", "G-BF2FDR6KMM");
"use strict";

!function (f, b, e, v, n, t, s) {
  if (f.fbq) return;

  n = f.fbq = function () {
    n.callMethod ? n.callMethod.apply(n, arguments) : n.queue.push(arguments);
  };

  if (!f._fbq) f._fbq = n;
  n.push = n;
  n.loaded = !0;
  n.version = '2.0';
  n.queue = [];
  t = b.createElement(e);
  t.async = !0;

  t.onload = () => Core.utils.onAllowCookieTracking(() => f.fbq('consent', 'grant'));

  t.src = v;
  s = b.getElementsByTagName(e)[0];
  s.parentNode.insertBefore(t, s);
}(window, document, 'script', 'https://connect.facebook.net/en_US/fbevents.js');
fbq('consent', 'revoke');
fbq('init', '282429905966327');
fbq('track', 'PageView');

var t=document.createElement("script");t.type="text/javascript",t.addEventListener("load",()=>{window.tti.calculateTTI(({name:t,value:e}={})=>{let i={"wam_site_hasPopupWidget":false,"wam_site_hasMessagingWidget":true,"wam_site_headerTreatment":false,"wam_site_hasSlideshow":false,"wam_site_hasFreemiumBanner":false,"wam_site_homepageFirstWidgetType":"ABOUT","wam_site_homepageFirstWidgetPreset":"about2","wam_site_businessCategory":"web_design","wam_site_theme":"layout10","wam_site_locale":"en-IN","wam_site_fontPack":"roboto","wam_site_cookieBannerEnabled":true,"wam_site_membershipEnabled":false,"wam_site_hasHomepageHTML":false,"wam_site_hasHomepageShop":false,"wam_site_hasHomepageOla":true,"wam_site_hasHomepageBlog":false,"wam_site_hasShop":false,"wam_site_hasOla":true,"wam_site_planType":"simple","wam_site_isHomepage":false,"wam_site_htmlWidget":false};window.networkInfo&&window.networkInfo.downlink&&(i=Object.assign({},i,{["wam_site_networkSpeed"]:window.networkInfo.downlink.toFixed(2)})),window.tti.setCustomProperties(i),window.tti._collectVitals({name:t,value:e})})}),t.setAttribute("src","//img1.wsimg.com/traffic-assets/js/tccl-tti.min.js"),document.body.appendChild(t);</script>
<script defer src="//img1.wsimg.com/traffic-assets/js/tccl.min.js" crossorigin></script>
<script>Core.utils.onAllowCookieTracking(()=>{let e=window.location.search,l=new URLSearchParams(e),i=l.get("gclid");i&&localStorage.setItem("gclid",i)});</script></body></html>